import React from "react"

/**
 * Challenge: Build the Header component
 */
export default function App() {
    return <h1>Hello world!</h1>
}
